/*
Navicat MySQL Data Transfer

Source Server         : test
Source Server Version : 50716
Source Host           : 192.168.0.110:3306
Source Database       : springboot

Target Server Type    : MYSQL
Target Server Version : 50716
File Encoding         : 65001

Date: 2017-03-19 23:36:25
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for t_user
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nickname` varchar(20) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `sign` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('1', '张三', '2000-01-02', '土地是以它的肥沃和收获而被估价的；才能也是土地，不过它生产的不是粮食，而是真理。如果只能滋生瞑想和幻想的话，即使再大的才能也只是砂地或盐池，那上面连小草也长不出来的。');
INSERT INTO `t_user` VALUES ('2', '李四', '2017-03-14', '人生就像是一场修行');
INSERT INTO `t_user` VALUES ('3', '王五', '2000-01-02', '我需要三件东西：爱情友谊和图书。然而这三者之间何其相通！炽热的爱情可以充实图书的内容，图书又是人们最忠实的朋友。');
INSERT INTO `t_user` VALUES ('4', '赵六', '2000-01-02', '真理惟一可靠的标准就是永远自相符合。');
INSERT INTO `t_user` VALUES ('5', '周七', '2000-01-02', '世间是一切财富中最宝贵的财富。');
INSERT INTO `t_user` VALUES ('6', '王霸', '2000-01-02', '世界上一成不变的东西，只有“任何事物都是在不断变化的”这条真理。');
INSERT INTO `t_user` VALUES ('7', '任琦', '2017-03-07', '如果刀刃怕伤了自己而不与磨刀石接触，就永远不会锋利。');
INSERT INTO `t_user` VALUES ('8', '牢拔', '2017-03-31', '在懒汉的眼里，汗是苦的，脏的；在勤者的心上，汗是甜的，美的。');
INSERT INTO `t_user` VALUES ('9', '欧文', '2017-03-30', '爱情原如树叶一样，在人忽视里绿了，在忍耐里露出蓓蕾。');
INSERT INTO `t_user` VALUES ('10', '蒙田', '2000-01-02', '友谊的小船说翻就翻');
INSERT INTO `t_user` VALUES ('11', ' 纪伯伦', '2000-01-02', '一件事实是一条没有性别的真理');
INSERT INTO `t_user` VALUES ('12', '陈潭秋', '2017-03-29', '不达成功誓不休。');
INSERT INTO `t_user` VALUES ('13', '老罗', '1897-05-28', '爱情只有当它是自由自在时，才会叶茂花繁。认为爱情是某种义务的思想只能置爱情于死地。只消一句话：你应当爱某个人，就足以使你对这个人恨之入骨。');
