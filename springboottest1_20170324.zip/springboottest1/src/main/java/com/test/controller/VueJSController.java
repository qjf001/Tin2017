package com.test.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017/3/8 0008.
 */
@Controller
@RequestMapping("vuejs")
public class VueJSController {

    @RequestMapping("helloVue")
    public String helloVue()
    {
        return "vue/helloVue";
    }
    @RequestMapping("table")
    public String table(Model model)
    {
        return "vue/table2";
    }

    @ResponseBody
    @RequestMapping("getTableData")
    public Map getTableData(Integer currentPage,Integer pageSize)
    {
        Map<String,Object> rdata = new HashMap<>();
        List<Map> datas = new ArrayList<>();
        Map<String,Object> map1 = new HashMap<>();
        map1.put("id",1);
        map1.put("nickname","张三");
            map1.put("birthday","2000-01-02");
        map1.put("sign","人生就像是一场修行人生就像是一场修行人生就像是一场修行人生就像是一场修行人生就像是一场修行人生就像是一场修行人生就像是一场修行人生就像是一场修行");
        Map<String,Object> map2 = new HashMap<>();
        map2.put("id",2);
        map2.put("nickname","李四");
        map2.put("birthday","2000-01-02");
        map2.put("sign","人生就像是一场修行");
        Map<String,Object> map3 = new HashMap<>();
        map3.put("id",3);
        map3.put("nickname","王五");
        map3.put("birthday","2000-01-02");
        map3.put("sign","人生就像是一场修行");
        Map<String,Object> map4 = new HashMap<>();
        map4.put("id",4);
        map4.put("nickname","赵六");
        map4.put("birthday","2000-01-02");
        map4.put("sign","人生就像是一场修行");
        Map<String,Object> map5 = new HashMap<>();
        map5.put("id",5);
        map5.put("nickname","周七");
        map5.put("birthday","2000-01-02");
        map5.put("sign","人生就像是一场修行");
        Map<String,Object> map6 = new HashMap<>();
        map6.put("id",6);
        map6.put("nickname","王霸");
        map6.put("birthday","2000-01-02");
        map6.put("sign","人生就像是一场修行人生就像是一场修行人生就像是一场修行人生就像是一场修行人生就像是一场修行人生就像是一场修行人生就像是一场修行人生就像是一场修行");
        Map<String,Object> map7 = new HashMap<>();
        map7.put("id",7);
        map7.put("nickname","任琦");
        map7.put("birthday","2000-01-02");
        map7.put("sign","人生就像是一场修行");
        Map<String,Object> map8 = new HashMap<>();
        map8.put("id",8);
        map8.put("nickname","牢拔");
        map8.put("birthday","2000-01-02");
        map8.put("sign","人生就像是一场修行");
        Map<String,Object> map9 = new HashMap<>();
        map9.put("id",9);
        map9.put("nickname","醋老西");
        map9.put("birthday","2000-01-02");
        map9.put("sign","人生就像是一场修行");
        Map<String,Object> map10 = new HashMap<>();
        map10.put("id",10);
        map10.put("nickname","施法");
        map10.put("birthday","2000-01-02");
        map10.put("sign","人生就像是一场修行");
        datas.add(map1);
        datas.add(map2);
        datas.add(map3);
        datas.add(map4);
        datas.add(map5);
        datas.add(map6);
        datas.add(map7);
        datas.add(map8);
        datas.add(map9);
        datas.add(map10);
        int start = (currentPage-1)*pageSize;
        rdata.put("list",datas.subList(start,currentPage*pageSize));

        Map<String,Integer> page = new HashMap<>();
        page.put("total",datas.size());
        page.put("currentPage",currentPage);
        page.put("pageSize",pageSize);

        rdata.put("page",page);

        return rdata;
    }
}
