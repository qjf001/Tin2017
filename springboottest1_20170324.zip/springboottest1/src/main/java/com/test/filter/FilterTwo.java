package com.test.filter;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * Created by Administrator on 2017/2/28.
 */
/**
 *
 * Spring boot 的主 Servlet 为 DispatcherServlet，其默认的url-pattern为“/”。
 *
 * 在spring boot中添加自己的Servlet有两种方法，代码注册Servlet和注解自动注册（Filter和Listener也是如此）。
 一、代码注册通过ServletRegistrationBean、 FilterRegistrationBean 和 ServletListenerRegistrationBean 获得控制。
 也可以通过实现 ServletContextInitializer 接口直接注册。
 * e
 * 二、在 SpringBootApplication 上使用@ServletComponentScan 注解后，
 * Servlet、Filter、Listener 可以直接通过 @WebServlet、@WebFilter、@WebListener 注解自动注册，无需其他代码。
 * **/

/**   beans被定义必须以特定的次序调用，你可以额外实现org.springframework.core.Ordered接口或使用@Order注解。 **/
/*@Order(100)
@WebFilter(filterName="filterTwo",urlPatterns="*//*")*/
public class FilterTwo implements Filter /*, Ordered*/ {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("~~~~~~~~~~~~~~~~~~~spring boot filter two init~~~~~~~~~~~~~~~~~~~~~~~~~");
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

        System.out.println("~~~~~~~~~~~~~~~~~~~spring boot filter two "+((HttpServletRequest)servletRequest).getRequestURI()+" ~~~~~~~~~~~~~~~~~~~~~~~~~");
        filterChain.doFilter(servletRequest,servletResponse);
    }

    @Override
    public void destroy() {
        System.out.println("~~~~~~~~~~~~~~~~~~~spring boot filter two destroy~~~~~~~~~~~~~~~~~~~~~~~~~");
    }

  /*  @Override
    public int getOrder() {
        return 100;
    }*/
}
