/**
 * Created by Administrator on 2017/3/27 0027.
 */
layui.use(['form', 'layedit', 'laydate','laytpl','jquery'], function(){
    var form = layui.form(),$=layui.jquery
        ,layer = layui.layer
        ,layedit = layui.layedit
        ,laydate = layui.laydate;

    // 绘制表单
    layui.laytpl(formTpl.innerHTML).render(window.formRows, function(html){
        aform.innerHTML = html;
    });

    //遍历每一个表单元素，绑定富文本编辑器
    $.each(window.formRows,function(ind,valu){
        if($.isArray(valu))
        {
            $.each(valu,function(i,v){
                if(v.type==='textEdit')
                    var editIndex = layedit.build(v.formId);
            });
        }
        else {
            if(valu.type==='textEdit')
                var editIndex = layedit.build(valu.formId);
        }
    });
    form.render();


/*

    //自定义验证规则
    form.verify({
        title: function(value){
            if(value.length < 5){
                return '标题至少得5个字符啊';
            }
        }
        ,pass: [/(.+){6,12}$/, '密码必须6到12位']
        ,content: function(value){
            layedit.sync(editIndex);
        }
    });

    //监听指定开关
    form.on('switch(switchTest)', function(data){
        layer.msg('开关checked：'+ (this.checked ? 'true' : 'false'), {
            offset: '6px'
        });
        layer.tips('温馨提示：请注意开关状态的文字可以随意定义，而不仅仅是ON|OFF', data.othis)
    });

    //监听提交
    form.on('submit(demo1)', function(data){
        layer.alert(JSON.stringify(data.field), {
            title: '最终的提交信息'
        })
        return false;
    });
*/


});