package com.test.controller;

import com.test.common.util.LocaleMessageSourceUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfig;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;

/**
 * Created by Administrator on 2017/3/7.
 */
@Controller
public class WebController {

    @Autowired
    private FreeMarkerConfig freeMarkerConfig;//获取FreemarkerConfig的实例

    @Autowired
    private LocaleMessageSourceUtil localeMessageSourceUtil;

//    @NotEmpty // 用在集合类上面 org.hibernate.validator.constraints.NotEmpty;
//    @NotBlank // 用在String上面 org.hibernate.validator.constraints.NotBlankv;
//    @NotNull // 用在基本类型上  javax.validation.constraints.NotNull;
//    //${ property : default_value }
    @Value("${application.message:1234556677}")// 如果配置文件中没有application.message属性或者没有属性值，使用这个默认值
//    @Value("${application.message}")// 如果配置文件中没有这个属性application.message，则自动报错
    private String message ;

    @RequestMapping(value={"","/","/index"})
    public String web(Map<String,Object> model, HttpServletRequest req){
        System.out.println("local~~~~~~~~~~~~~~~"+req.getLocales());
        model.put("timeStr",new Date());
        model.put("messageStr",this.message);
        model.put("welcome",localeMessageSourceUtil.getMessage("welcome"));
        Object[] params = {"John", new GregorianCalendar().getTime(), 1.0E3};
        model.put("John",localeMessageSourceUtil.getMessage("user_save",params));
        model.put("John2",params);
        return "web1";//返回的内容就是templetes下面文件的名称
    }

}
