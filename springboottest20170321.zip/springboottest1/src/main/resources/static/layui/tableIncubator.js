﻿layui.use(['laytpl', 'element','jquery','form','laypage','laydate'], function(){
  var form=layui.form(),$=layui.jquery;window.tableTpl = tableTpl.innerHTML;

	// 初始化button 组(新增、批量删除等)
	if(window.bts){
		layui.laytpl(leftTopBtGroupTpl.innerHTML).render(window.bts, function(html){
			btArea.innerHTML = html;
		});
	}
	if(window.searchInputs){
		layui.laytpl(searchFormTpl.innerHTML).render(window.searchInputs, function(html){
			searchForm.innerHTML = html;
		});
	}
	form.render();//searchForm以静态的方式插入到指定区域，需要动态渲染一下 form.render('select');
	try{
		if(typeof(urlStr)!='string'){alert("urlStr is not string or urlStr is not defined");return false;}
	}catch(e) {alert("urlStr is not defined");throw new Error("urlStr is not defined");return false;}
	try{
		if(!columns instanceof Array){alert("columns is not array");return false;}
	}catch(e) {alert("columns is not defined");throw new Error("columns is not defined");return false;}
	window._pageSize = (!window.pageSize) ? 10 : pageSize;//维持一个全局变量，然后将声明的全局变量的值赋给去全局变量
	window._layPageCurrentPage = 1;

	auto_initDataGrid(urlStr,1);// 页面打开，初始化数据表格第一页

	$('#moreOpenOrClose').on('click',function() {
		if ($(this).hasClass('moreClose')) {
			$(this).removeClass('moreClose');
			$(this).addClass('moreOpen');
			$(this).find('i.layui-icon').html('&#xe61a;');
			$('#moreSearchItem').addClass('layui-show');
		}
		else
		{
			$(this).removeClass('moreOpen');
			$(this).addClass('moreClose');
			$(this).find('i.layui-icon').html('&#xe619;');
			$('#moreSearchItem').removeClass('layui-show');
		}
	});


});

var getAllCheckedAttr = function()
{	
	var ids = [];
	var $ = layui.jquery;
	var child = $('table.layui-table').find('tbody div.layui-form-checked');
	child.each(function(index, item){
		var _thisId=$(this).attr('data-id');
		if(_thisId &&　_thisId!='undefined')ids.push(_thisId);
	});
	console.log(ids);
	return ids;
}
var getAllCheckedObj = function()
{	
	var objects = [];
	var $ = layui.jquery;
	var child = $('table.layui-table').find('tbody div.layui-form-checked');
	child.each(function(index, item){
		objects.push($(this).parents('tr'));
	});
	console.log(objects);
	return objects;
}
var auto_initDataGrid = function(urlStr,currentPage){
	var laytpl = layui.laytpl; var $=layui.jquery;
	// 获取请求参数：1、翻页参数pageNum和pageSize，2、查询条件
	var searchItem = $("#searchForm").serialize();
	console.log(searchItem);
	$.ajax({
		url:urlStr+"?pageNum="+currentPage+"&pageSize="+_pageSize+"&"+searchItem,
		async:false,
		dataType:"json",
		success:function(data){
			var page = data.page;
			var allWidth = 0;
			$.each(columns,function(ind,valu){allWidth += (valu.width) ? valu.width : 0;});
			allWidth = (allWidth==0) ? columns.length : allWidth;
			$.each(columns,function(ind,valu){if(valu.width) valu.width = valu.width/allWidth*100;});
			page.columns=columns;
			page.noDataContent = (!window.noDataContent) ? '无数据' : noDataContent;
			page.title = (!window.title) ? '' : title;
			page.checkbox=(window.hasCheckbox===undefined) ? true : window.hasCheckbox;
			laytpl(tableTpl).render(page, function(html){
				tableGrid.innerHTML = html;
			});
			window._pageSize=page.pageSize;
			auto_initPager(page);
		}
	});
}
var auto_initPager = function(page)
{
	var $=layui.jquery;
	// 这个分页是否适合ajax-load?
	// 1、首先需要知道记录总数或者总页数，这个数据包含在ajax请求返回的数据中
	// 2、其次jump 的主要作用是获取数据并填充到相应的区域
	// 1和2在逻辑上有冲突啊？？？
	layui.laypage({// 实例化分页
		cont: 'pager'
		,curr:page.pageNum
		,pages: page.pages //得到总页数
		,skip: true
	});
	// 翻页事件手动绑定
	$('#pager .layui-laypage a').on('click',function(){
	 	auto_initDataGrid(urlStr,$(this).attr("data-page"),_pageSize);
	 });
	$('#pager button.layui-laypage-btn').on('click',function(){
		var skipNum = $('#pager input.layui-laypage-skip').val();
		auto_initDataGrid(urlStr,skipNum,_pageSize);
	});
}
var childClick = function(obj){
	var $=layui.jquery;
	if($(obj).hasClass('layui-form-checked'))
		$(obj).removeClass('layui-form-checked');
	else
		$(obj).addClass('layui-form-checked');
}
var parentClick = function(obj)
{
	var $=layui.jquery;
	var child = $('table.layui-table').find('tbody div.layui-form-checkbox');
	if(!$(obj).hasClass('layui-form-checked'))
	{
		$(obj).addClass('layui-form-checked');
		child.each(function(index, item){$(this).addClass('layui-form-checked');});
	}
	else
	{
		$(obj).removeClass('layui-form-checked');
		child.each(function(index, item){$(this).removeClass('layui-form-checked');});
	}
}