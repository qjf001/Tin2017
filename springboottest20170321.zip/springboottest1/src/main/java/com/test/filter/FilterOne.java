package com.test.filter;

import org.springframework.core.annotation.Order;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * Created by Administrator on 2017/2/28.
 */
/**
 *
 * Spring boot 的主 Servlet 为 DispatcherServlet，其默认的url-pattern为“/”。
 *
 * 在spring boot中添加自己的Servlet有两种方法，代码注册Servlet和注解自动注册（Filter和Listener也是如此）。
 一、代码注册通过ServletRegistrationBean、 FilterRegistrationBean 和 ServletListenerRegistrationBean 获得控制。
 也可以通过实现 ServletContextInitializer 接口直接注册。
 * e
 * 二、在 SpringBootApplication 上使用@ServletComponentScan 注解后，
 * Servlet、Filter、Listener 可以直接通过 @WebServlet、@WebFilter、@WebListener 注解自动注册，无需其他代码。
 * **/
/**
 * 不起作用 beans被定义必须以特定的次序调用，你可以额外实现org.springframework.core.Ordered接口或使用@Order注解。
 * @WebFilter注解是javax.servlet.annotation的注解通过ordered无法控制执行顺序，
 * 可以在入口类中声明@Bean FilterRegistrationBean,然后setOrder
 * **/
//@Order(0)
//@WebFilter(filterName="filterOne",urlPatterns="/*")
public class FilterOne implements Filter /*, Ordered*/ {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("~~~~~~~~~~~~~~~~~~~spring boot filter one init~~~~~~~~~~~~~~~~~~~~~~~~~");
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

        System.out.println("~~~~~~~~~~~~~~~~~~~spring boot filter one ~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("~~~~~~~~~~~~~~~~~~~"+((HttpServletRequest)servletRequest).getRequestURI()+" ~~~~~~~~~~~~~~~~~~~~~~~~~");
        filterChain.doFilter(servletRequest,servletResponse);
    }

    @Override
    public void destroy() {
        System.out.println("~~~~~~~~~~~~~~~~~~~spring boot filter one destroy~~~~~~~~~~~~~~~~~~~~~~~~~");
    }

  /*  @Override
    public int getOrder() {
        return 0;
    }*/
}
