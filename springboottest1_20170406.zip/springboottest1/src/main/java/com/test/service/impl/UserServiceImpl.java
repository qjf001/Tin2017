package com.test.service.impl;

import com.github.pagehelper.PageHelper;
import com.test.entity.User;
import com.test.entity.UserExample;
import com.test.mapper.UserMapper;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by Administrator on 2017/3/18 0018.
 * @Transactional 遇到RuntimeException会回滚，遇到Exception不会滚
 * @Transactional(rollbackFor = Exception.class)  出现Exception和RuntimeExcetion都会回滚，因为RuntimeExcetion是Exception的子类
 *
 * isolation= Isolation.DEFAULT 事务隔离级别 默认的事务隔离级别，默认采用数据源的默认事务隔离级别。（注意如果没有采用默认的隔离级别，有的数据源可能不支持你设置的隔离级别。）
 *
 * value String 可选的限定描述符，指定使用的事务管理器（如果有多个数据源及事务管理器，可以配置这个属性）
 *
 *  @Transactional(propagation=Propagation.REQUIRED)
 *  如果有事务, 那么加入事务, 没有的话新建一个(默认情况下)
 *  @Transactional(propagation=Propagation.NOT_SUPPORTED)
 *  容器不为这个方法开启事务
 *  @Transactional(propagation=Propagation.REQUIRES_NEW)
 *  不管是否存在事务,都创建一个新的事务,原来的挂起,新的执行完毕,继续执行老的事务
 * @Transactional(propagation=Propagation.MANDATORY)
 * 必须在一个已有的事务中执行,否则抛出异常
 * @Transactional(propagation=Propagation.NEVER)
 * 必须在一个没有的事务中执行,否则抛出异常(与Propagation.MANDATORY相反)
 * @Transactional(propagation=Propagation.SUPPORTS)
 * 如果其他bean调用这个方法,在其他bean中声明事务,那就用事务.如果其他bean没有声明事务,那就不用事务.
 *
 * 事物超时设置:
 * @Transactional(timeout=30) //默认是30秒

 * @Transactional 只能被应用到public方法上, 对于其它非public的方法,如果标记了@Transactional也不会报错,但方法没有事务功能.
 *
 * @Transactional 注解可以被应用于接口定义和接口方法、类定义和类的 public 方法上。然而，请注意仅仅 @Transactional 注解的出现不足于开启事务行为，
 * 它仅仅 是一种元数据，能够被可以识别 @Transactional 注解和上述的配置适当的具有事务行为的beans所使用。上面的例子中，其实正是 <tx:annotation-driven/>元素的出现 开启 了事务行为。
 * Spring团队的建议是你在具体的类（或类的方法）上使用 @Transactional 注解，而不要使用在类所要实现的任何接口上。
 */
@Service
@Transactional(rollbackFor = Exception.class,isolation= Isolation.DEFAULT)
public class UserServiceImpl {

    @Resource
    private UserMapper userMapper;

    public List<User> findPage(int pageNum, int pageSize,String birthday) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        PageHelper.startPage( pageNum,  pageSize);
        UserExample ue = new UserExample();
        if(!StringUtils.isBlank(birthday))
            ue.createCriteria().andBirthdayLessThanOrEqualTo(sdf.parse(birthday));
        ue.setOrderByClause(" id ");
        return userMapper.selectByExample(ue);
    }

    public User get(Integer id)
    {
        return userMapper.selectByPrimaryKey(id);
    }

    public void saveOrUpdate(User user) {
        if(null != user.getId())
            userMapper.updateByPrimaryKey(user);
        else
            userMapper.insert(user);
    }

    public void delete(Integer id) {
        userMapper.deleteByPrimaryKey(id);
       /* if(1==1)
            throw new RuntimeException("1231212131");
        User user = new User();
        user.setId(id);
        user.setNickname("王羲之");
        user.setGender((byte)1);
        user.setWorkCity((byte)2);
        user.setBirthday(new Date(303,12,12));
        user.setMemo("晚年即在金庭养老，直至去世");
        userMapper.insert(user);
        */
    }
}
