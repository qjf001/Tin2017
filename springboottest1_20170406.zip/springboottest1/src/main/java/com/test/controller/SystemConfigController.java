package com.test.controller;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by Administrator on 2017/4/4 0004.
 *
 * 系统配置
 */
@Controller
@RequestMapping("admin")
public class SystemConfigController {


   private static final String KEY1 = "spring.freemarker.template-loader-path";
   private static final String KEY2 = "spring.freemarker.suffix";
   private static final String START = "<script type=\"text/javascript\">";
   private static final String END = "</script>";
   private static String SUFFIX = ".ftl";


    @RequestMapping("createListPage")
    public String createListPage()
    {
        return "createListPage";
    }

    @RequestMapping("saveListPage")
    @ResponseBody
    public Map saveListPage(HttpServletRequest req)
    {
        Map map = new HashMap<>();

        try{
            createPage(req);

            map.put("action",true);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            map.put("action",false);
        }
        return map;
    }

    private String createPage(HttpServletRequest req) throws IOException {
        Map<String,String[]> pMap = req.getParameterMap();
        Set<Map.Entry<String,String[]>> sets = pMap.entrySet();
        Map<String,String[]> golbal_var_map = sets.stream().filter(entry -> entry.getKey().toString().startsWith("golbal_")).collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getValue));
        Map<String,String[]> bt_var_map = sets.stream().filter(entry -> entry.getKey().toString().startsWith("bt_")).collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getValue));
        Map<String,String[]> search_var_map = sets.stream().filter(entry -> entry.getKey().toString().startsWith("search_")).collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getValue));
        Map<String,String[]> table_var_map = sets.stream().filter(entry -> entry.getKey().toString().startsWith("table_")).collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getValue));

        Object obj_pageUri = golbal_var_map.get("golbal_pageUri");
        if(null != obj_pageUri)
        {
            String[] golbal_pageUri = (String[])obj_pageUri;
            String pageUri = golbal_pageUri[0];
           if(pageUri.startsWith("/"))
               pageUri=pageUri.substring(1,pageUri.length());
            String filePath = getFilePath()+pageUri+SUFFIX;
            File file = new File(filePath);


            if(file.exists())// 需要覆盖吗
            {

            }
            else {
                if(file.createNewFile())
                {
                    try (BufferedWriter bw = new BufferedWriter(new FileWriter(new File(filePath)))){
                        bw.write(START);
                        bw.newLine();
                        // var urlStr = "/user/listData",title = "用户列表",pageSize=2;
                        String golbal_var = "var urlStr =\""+golbal_var_map.get("golbal_dataUri")[0]+"\" ,";
                        golbal_var += "title = \""+golbal_var_map.get("golbal_pageTitle")[0]+"\" ,";
                        golbal_var += "pageSize="+golbal_var_map.get("golbal_pageSize")[0]+" ; ";
                        bw.write(golbal_var);
                        bw.newLine();

                        buildBtVar(bw ,bt_var_map);
                        bw.newLine();
                        buildSearchVar(bw ,search_var_map);
                        bw.newLine();
                        buildListVar(bw ,table_var_map);

                        String[] golbal_page_script = golbal_var_map.get("golbal_page_script");
                        if(null != golbal_page_script && golbal_page_script.length > 0)
                        {
                            String golbal_script = golbal_page_script[0];
                            if(!StringUtils.isBlank(golbal_script))
                            {
                                bw.newLine();
                                bw.write(golbal_script);
                            }
                        }

                        bw.newLine();
                        bw.write(END);
                        bw.flush();
                    }
                    catch(Exception e)
                    {
                        e.printStackTrace();
                    }
                }
            }
        }
        return null;
    }

    private void buildListVar(BufferedWriter bw, Map<String, String[]> table_var_map) throws IOException {

        if(table_var_map!=null && !table_var_map.isEmpty())
        {

            Map<String,List<String>> keymap = getKeyMap( table_var_map);

            bw.write("var columns =[ ");

            String[] numKey = keymap.keySet().toArray(new String[keymap.keySet().size()]);
            for(int i=0;i<numKey.length;i++)
            {
                StringBuffer sb = new StringBuffer("    { ");
                String keyStr = numKey[i];
                List<String> keySet = keymap.get(keyStr);
                for(String key: keySet)
                {
                    Object val = table_var_map.get(key);
                    String value = null;
                    if(null != val)
                        value = ((String[])val)[0];
                    if(!StringUtils.isBlank(value))
                    {
                        String name = (key.split("_"))[1];
                        switch(name) {
                            case "title":
                                sb.append(" title:\""+value+"\", ");
                                break;
                            case "field":
                                sb.append(" field:\""+value+"\", ");
                                break;
                            case "width":
                                sb.append(" width:"+value+", ");
                                break;
                            case "align":
                                sb.append(" align:\""+value+"\", ");
                                break;
                            case "autoScreen":
                                sb.append(" autoScreen:\""+value+"\", ");
                                break;
                            case "style":
                                sb.append(" style:\""+value+"\", ");
                                break;
                            case "class":
                                sb.append(" classes:\""+value+"\", ");
                                break;
                            case "formatter":
                                sb.append(" formatter:"+value+", ");
                                break;
                            default: break;
                        }
                    }
                }

                if(sb.toString().endsWith(", "))
                    sb.deleteCharAt(sb.length()-2);
                if(i!=numKey.length-1)
                    sb.append(" } ,");
                else
                    sb.append(" }");

                bw.newLine();
                bw.write(sb.toString());
            }
            bw.newLine();
            bw.write(" ]; ");
        }


    }

    /**
     *
     *
     *
     * var searchInputs = [
     {type:"text"   ,labelName:"姓名",formId:"nickname",formName:"nickname",style:"",placeholder:"请输入姓名"},
     {type:"select" ,labelName:"选择框",formId:"modules",formName:"modules", options:[{v:"",t:"直接选择或搜索选择"},{v:"1",t:"layer"},{v:"2",t:"form"},{v:"3",t:"layim",defaultSelect:true}],laySearch:false},
     {type:"date"   ,labelName:"生日",formId:"birthday",formName:"birthday",clickEvent:"layui.laydate({elem: this, festival: true,min:'0000-01-01 00:00:00',max:'5000-01-01 00:00:00', format: 'YYYY-MM-DD'});",placeholder:"带有日期的节日"}
     ];
     * **/
    private void buildSearchVar(BufferedWriter bw, Map<String, String[]> search_var_map) throws IOException {
        if(search_var_map!=null && !search_var_map.isEmpty())
        {

            Map<String,List<String>> keymap = getKeyMap( search_var_map);

            bw.write("var searchInputs = [ ");

            String[] numKey = keymap.keySet().toArray(new String[keymap.keySet().size()]);
            for(int i=0;i<numKey.length;i++)
            {
                StringBuffer sb = new StringBuffer("    { ");
                String keyStr = numKey[i];
                List<String> keySet = keymap.get(keyStr);
                for(String key: keySet)
                {
                    Object val = search_var_map.get(key);
                    String value = null;
                    if(null != val)
                        value = ((String[])val)[0];
                    if(!StringUtils.isBlank(value))
                    {
                        String name = (key.split("_"))[1];
                        switch(name) {
                            case "type":
                                sb.append(" type:\""+value+"\", ");
                                break;
                            case "label":
                                sb.append(" labelName:\""+value+"\", ");
                                break;
                            case "id":
                                sb.append(" formId:\""+value+"\", ");
                                break;
                            case "formName":
                                sb.append(" formName:\""+value+"\", ");
                                break;
                            case "autoScreen":
                                sb.append(" autoScreen:\""+value+"\", ");
                                break;
                            case "click":
                                sb.append(" clickEvent:\""+value+"\", ");
                                break;
                            case "selectOptions":
                                sb.append(" options: [ ");
                                String[] values = value.split(",");
                                for(int k=0;k<values.length;k++)
                                {
                                    String[] vals = values[k].split(":");
                                    sb.append( "{v:"+"\""+vals[0]+"\",t:"+"\""+vals[1]+"\"}");
                                    if(k!=values.length-1)
                                        sb.append(" , ");
                                }
                                sb.append(" ] ");
                                break;

                            default: break;
                        }
                    }
                }

                if(sb.toString().endsWith(", "))
                    sb.deleteCharAt(sb.length()-2);
                if(i!=numKey.length-1)
                    sb.append(" } ,");
                else
                    sb.append(" }");

                bw.newLine();
                bw.write(sb.toString());
            }
            bw.newLine();
            bw.write(" ]; ");
        }

    }

    /**
     *  <label>名称</label><input type="text" name="bt_name_1" lay-verify="required" value="刷新" />
     <label>icon</label><input type="text" name="bt_icon_1" value="&amp;#x1002;"  />
     <label>click事件</label><input type="text" lay-verify="required" name="bt_click_1" value="auto_initDataGrid(urlStr,_pageNum);" />
     <label>id</label><input type="text" name="bt_id_1" value="" />
     <label>filterName</label><input type="text" lay-verify="required" name="bt_filterName_1" />
     * var bts = [
     {btName:"刷新",classes:"layui-btn-small",icon:"&#x1002;",clickEvent:"auto_initDataGrid(urlStr,_pageNum);"},
     {btName:"新增",id:"bt_add2",clickEvent:"openPage('edit','编辑用户信息');" ,icon:"&#xe608;",classes:"layui-btn-small layui-btn-warm",style:""},
     {btName:"删除" ,id:"bt_del" ,clickEvent:"var ids=getAllCheckedAttr();layui.layer.alert(ids.join(','));" ,icon:"&#xe640;",classes:"layui-btn-small",style:""}
     ];
     * */
    /**
     * 对于bt_var_map进行分组
     *
     * */
    private String buildBtVar(BufferedWriter bw ,Map<String, String[]> bt_var_map) throws IOException {

        if(bt_var_map!=null && !bt_var_map.isEmpty())
        {
            Map<String,List<String>> keymap = getKeyMap( bt_var_map);

            bw.write("var bts = [ ");

            String[] numKey = keymap.keySet().toArray(new String[keymap.keySet().size()]);
            for(int i=0;i<numKey.length;i++)
            {
                StringBuffer sb = new StringBuffer("    { ");
                String keyStr = numKey[i];
                List<String> keySet = keymap.get(keyStr);
                for(String key: keySet)
                {
                    Object val = bt_var_map.get(key);
                    String value = null;
                    if(null != val)
                        value = ((String[])val)[0];
                    if(!StringUtils.isBlank(value))
                    {
                        String name = (key.split("_"))[1];
                        switch(name) {
                            case "name":
                                sb.append(" btName:\""+value+"\", ");
                                break;
                            case "id":
                                sb.append(" id:\""+value+"\", ");
                                break;
                            case "icon":
                                sb.append(" icon:\""+value+"\", ");
                                break;
                            case "click":
                                sb.append(" clickEvent:\""+value+"\", ");
                                break;
                            case "filterName":
                                sb.append(" filterName:\""+value+"\", ");
                                break;
                            case "classes":
                                sb.append(" classes:\""+value+"\", ");
                                break;
                            case "style":
                                sb.append(" style:\""+value+"\", ");
                                break;
                            default: break;
                        }
                    }
                }

                if(sb.toString().endsWith(", "))
                    sb.deleteCharAt(sb.length()-2);
                if(i!=numKey.length-1)
                sb.append(" } ,");
                else
                    sb.append(" }");

                bw.newLine();
                bw.write(sb.toString());
            }
            bw.newLine();
            bw.write(" ]; ");
        }

        return null;
    }

    private Map<String,List<String>> getKeyMap(Map<String, String[]> var_map)
    {
        Set<String> keys = var_map.keySet();
        Map<String,List<String>> keymap = new HashMap<>();
        for(String key:keys)
        {
            String num = key.split("_")[2];
            List<String> keyList = keymap.get(num);
            if(null == keyList)
                keyList = new ArrayList<>();

            keyList.add(key);
            keymap.put(num,keyList);
        }
        return keymap;
    }

    private String getFilePath()
    {
        Properties prop = new Properties();
        String ftl_boot_path = "";
        SUFFIX = ".ftl";
        File f = new File(SystemConfigController.class.getResource("/").getPath());
        String classPath = f.getPath();
        try(FileInputStream fs = new FileInputStream(classPath+"/application.properties")){
            InputStream in = new BufferedInputStream(fs);
            prop.load(in);     ///加载属性列表
            ftl_boot_path = prop.get(KEY1).toString();
            SUFFIX = prop.get(KEY2).toString();
          //  System.out.println(System.getProperty("user.dir"));// 当前工程根路径
            ftl_boot_path = System.getProperty("user.dir")+"/src/main/resources"+ftl_boot_path.replaceAll("classpath:","");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return ftl_boot_path;
    }

    public static void main(String[] args) {

        Properties prop = new Properties();

        File f = new File(SystemConfigController.class.getResource("/").getPath());
        String classPath = f.getPath();
        System.out.println(classPath);
        try(FileInputStream fs = new FileInputStream(classPath+"/application.properties")){
            InputStream in = new BufferedInputStream(fs);
            prop.load(in);     ///加载属性列表
            String ftl_boot_path = prop.get(KEY1).toString();
            System.out.println(ftl_boot_path);
            System.out.println(System.getProperty("user.dir"));// 当前工程根路径
            ftl_boot_path = System.getProperty("user.dir")+"/src/main/resources"+ftl_boot_path.replaceAll("classpath:","");
            System.out.println(ftl_boot_path);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

}
