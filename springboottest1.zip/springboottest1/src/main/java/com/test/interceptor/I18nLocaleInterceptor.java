package com.test.interceptor;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.util.ObjectUtils;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.support.RequestContextUtils;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2017/3/8.
 */
public class I18nLocaleInterceptor extends LocaleChangeInterceptor {
    private String paramName = "locale";
    protected final Log logger = LogFactory.getLog(this.getClass());
    private static Map<String,String> systemLocales = new HashMap<>();
    static{
        systemLocales.put("en","en_us");
        systemLocales.put("zh","zh_cn");
        systemLocales.put("cn","zh_cn");
        systemLocales.put("hk","zh_tw");
        systemLocales.put("taiwan","zh_tw");
        systemLocales.put("zh_cn","zh_cn");
        systemLocales.put("zh_tw","zh_tw");
        systemLocales.put("en_us","en_us");
        systemLocales.put(null,"zh_cn");
    }

    public I18nLocaleInterceptor(String paramName) {
        this.paramName = paramName;
    }

    /**
     * en 转为 en_us
     * zh 转为 zh_cn
     * cn 转为 zh_cn
     * hk 转为 zh_tw
     * taiwan 转为 zh_tw
     * **/
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws ServletException {

        String newLocale ;

        String cookieLocal = getCookie(request);
        if(cookieLocal != null && cookieLocal.trim().length()>0)
        {
            newLocale = cookieLocal;
        }
        else {
            //String newLocale = request.getParameter(this.getParamName());
            String languageTag = LocaleContextHolder.getLocale().toLanguageTag();// 浏览器设置的语言，可能五花八门
            newLocale = (languageTag!=null && !languageTag.trim().equals("")) ? languageTag.replaceAll("\\-","_").toLowerCase() : null;
            // 如果没有匹配任何本系统中设置的语言 采用默认语言
            newLocale = systemLocales.getOrDefault(newLocale,systemLocales.get(null));//将浏览器国际化语言转为本系统的国际化语言
            setCookie(response,newLocale);
        }

        if(newLocale != null && this.checkHttpMethod(request.getMethod())) {
            LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(request);
            if(localeResolver == null) {
                throw new IllegalStateException("No LocaleResolver found: not in a DispatcherServlet request?");
            }

            try {
                localeResolver.setLocale(request, response, this.parseLocaleValue(newLocale));
            } catch (IllegalArgumentException var7) {
                if(!this.isIgnoreInvalidLocale()) {
                    throw var7;
                }

                this.logger.debug("Ignoring invalid locale value [" + newLocale + "]: " + var7.getMessage());
            }
        }

        return true;
    }

    private String getCookie(HttpServletRequest request)
    {
        String cookieLocal = null;
        Cookie[] cookies = request.getCookies();
        if(cookies!=null)
        {
            for(Cookie c: cookies)
            {
                if(c.getName().equals(this.getParamName()))
                {
                    cookieLocal = systemLocales.getOrDefault(c.getValue().toLowerCase(),"");
                    break;
                }
            }
        }

        return cookieLocal;
    }

    private void setCookie(HttpServletResponse response,String newLocale)
    {
        response.addCookie(new Cookie(this.getParamName(),newLocale));
    }

    private boolean checkHttpMethod(String currentMethod) {
        String[] configuredMethods = this.getHttpMethods();
        if(ObjectUtils.isEmpty(configuredMethods)) {
            return true;
        } else {
            String[] var3 = configuredMethods;
            int var4 = configuredMethods.length;

            for(int var5 = 0; var5 < var4; ++var5) {
                String configuredMethod = var3[var5];
                if(configuredMethod.equalsIgnoreCase(currentMethod)) {
                    return true;
                }
            }

            return false;
        }
    }

    @Override
    public String getParamName() {
        return paramName;
    }

    @Override
    public void setParamName(String paramName) {
        this.paramName = paramName;
    }
}
