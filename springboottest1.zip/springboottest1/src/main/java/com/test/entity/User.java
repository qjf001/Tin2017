package com.test.entity;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.Range;

/**
 * Created by Administrator on 2017/3/7.
 */

public class User {

    @NotBlank(message = "姓名不能为空")
    private String name;

    @Range
    private byte gender;

    private short age;

    private String email;

}
