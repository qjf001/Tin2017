package com.test.service.impl;

import com.github.pagehelper.PageHelper;
import com.test.entity.User;
import com.test.entity.UserExample;
import com.test.mapper.UserMapper;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

/**
 * Created by Administrator on 2017/3/18 0018.
 */
@Service
@Transactional
public class UserServiceImpl {

    @Resource
    private UserMapper userMapper;

    public List<User> findPage(int pageNum, int pageSize,String birthday) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        PageHelper.startPage( pageNum,  pageSize);
        UserExample ue = new UserExample();
        if(!StringUtils.isBlank(birthday))
            ue.createCriteria().andBirthdayLessThan(sdf.parse(birthday));
        ue.setOrderByClause(" id ");
        return userMapper.selectByExample(ue);
    }


}
