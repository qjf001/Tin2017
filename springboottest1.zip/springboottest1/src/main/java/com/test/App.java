package com.test;

import com.test.filter.FilterOne;
import com.test.filter.FilterTwo;
import com.test.interceptor.I18nLocaleInterceptor;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.data.elasticsearch.repository.config.EnableElasticsearchRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.PathMatchConfigurer;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import java.util.Collection;

/**
 * Created by Administrator on 2017/2/28.
 */
/**
 *
 * Spring boot 的主 Servlet 为 DispatcherServlet，其默认的url-pattern为“/”。
 *
 * 在spring boot中添加自己的Servlet有两种方法，代码注册Servlet和注解自动注册（Filter和Listener也是如此）。
 一、代码注册通过ServletRegistrationBean、 FilterRegistrationBean 和 ServletListenerRegistrationBean 获得控制。
 也可以通过实现 ServletContextInitializer 接口直接注册。
 * e
 * 二、在 SpringBootApplication 上使用@ServletComponentScan 注解后，
 * Servlet、Filter、Listener 可以直接通过 @WebServlet、@WebFilter、@WebListener 注解自动注册，无需其他代码。
 * **/

/** @EnableAutoConfiguration
 * 这个注解告诉Spring Boot根据添加的jar依赖猜测你想如何配置Spring。
 * 如果发现应用了你不想要的特定自动配置类，你可以使用 @EnableAutoConfiguration 注解的排除属性来禁用它们。
 * eg:@EnableAutoConfiguration(exclude={DataSourceAutoConfiguration.class})
 * **/
/**
 * @Configuration 注解该类，等价 与XML中配置beans； 负责注册bean，对应的提供了@Bean注解
 * 你不需要将所有的 @Configuration 放进一个单独的类。 @Import 注解可以用来导入其他配置类。
 * 另外，你也可以使用 @ComponentScan 注解自动收集所有的Spring组件，包括 @Configuration 类。
 * 如果你绝对需要使用基于XML的配置，我们建议你仍旧从一个 @Configuration 类开始。
 * 你可以使用附加的 @ImportResource 注解加载XML配置文件。
 * **/
/**
 *  @ComponentScan
 *   注解搜索beans，并结合 @Autowired 构造器注入。
 *  如果使用上面建议的结构组织代码（将应用类放到根包下），你可以添加 @ComponentScan 注解而不需要任何参数。
 *  你的所有应用程序组件（ @Component , @Service , @Repository , @Controller 等）将被自动注册为Spring Beans。
 * */
/**
 * @SpringBootApplication 注解等价于以默认属性使用 @Configuration ， @EnableAutoConfiguration 和 @ComponentScan 。
 * **/
/**
 * @Bean
 * 主要被用在方法上，来显式声明要用生成的类;用@Configuration注解该类，等价 与XML中配置beans；
 * 用@Bean标注方法等价于XML中配置bean。
 * */
/**
 * @Profiles
Spring Profiles提供了一种隔离应用程序配置的方式，并让这些配置只能在特定的环境下生效。
任何@Component或@Configuration都能被@Profile标记，从而限制加载它的时机。
以正常的Spring方式，你可以使用一个spring.profiles.active的Environment属性来指定哪个配置生效。
你可以使用平常的任何方式来指定该属性，例如，可以将它包含到你的application.properties中：
spring.profiles.active=dev,hsqldb
 * **/
//@EnableAutoConfiguration
//@ComponentScan
@ServletComponentScan
@SpringBootApplication
//@Configuration
@MapperScan("com.test.mapper")// 扫描mybaits的接口
@EnableElasticsearchRepositories(basePackages = "com.test")
@EnableTransactionManagement /** 启用注解式事务管理 <tx:annotation-driven /> **/
public class App extends WebMvcConfigurationSupport {
    public static void main(String[] args) {

        SpringApplication.run(App.class, args);

    }

    /*** 对于有顺序要求的filter以这种方式注册filter bean可以设置实例化顺序和执行顺序 **/
    @Bean
    public FilterRegistrationBean filterRegistrationTwo()
    {
        FilterRegistrationBean registration = new FilterRegistrationBean();
        registration.setFilter(new FilterTwo());
        registration.addUrlPatterns("/*");
        registration.setName("filterTwo");
        registration.setOrder(0);
        return registration;
    }
    @Bean
    public FilterRegistrationBean filterRegistrationOne()
    {
        FilterRegistrationBean registration = new FilterRegistrationBean();
        registration.setFilter(new FilterOne());
        registration.addUrlPatterns("/*");
        registration.setName("filterOne");
        registration.setOrder(1);
        return registration;
    }


    /** 使用nginx服务器时 */
    /** 使用resourceHandler处理静态资源,静态资源不走dispathservlet,否则404,使用静态资源时无需添加static目录 **/
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/**").addResourceLocations("classpath:/static/");
    }


    /** 设想将url后的参数lang在客户端写入到cookie中，后台从cookie中获取lang的值 **/
    /*** 设置拦截器开始 **/
    /**  作用：注册bean LocaleResolver，使用SessionLocaleResolver的对象注册，默认注册的是AcceptHeaderLocaleResolver对象
     *   AcceptHeaderLocaleResolver会出现Cannot change HTTP accept header - use a different locale resolution 的异常
     * **/
    @Bean
    public LocaleResolver localeResolver() {
        SessionLocaleResolver slr = new SessionLocaleResolver();
      //  slr.setDefaultLocale(Locale.SIMPLIFIED_CHINESE);
        return slr;
    }
    /** 改变locale的拦截器 **/
   /* @Bean
    public I18nLocaleInterceptor localeChangeInterceptor() {
        I18nLocaleInterceptor lci = new I18nLocaleInterceptor();
        lci.setParamName("lang");
        return lci;
    }*/
    @Bean
    public LocaleChangeInterceptor localeChangeInterceptor() {
        return new I18nLocaleInterceptor();
    }
    /** 将拦截器添加到拦截链中**/
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(localeChangeInterceptor()).addPathPatterns("/**").excludePathPatterns("/static/**");
        //super.addInterceptors(registry);
    }
    /*** 设置拦截器结束 **/



    // 默认情况下springboot的mvc路径匹配所有的后缀.xxx
    /**
     * setUseSuffixPatternMatch（Boolean  suffixPatternMatch）
     在将模式与请求匹配时是否使用后缀模式匹配（“.*”）。如果启用，映射到“/ users”的方法也匹配“/users.*”。
     默认情况下，设置为true。
     * */
    /**
     * setUseTrailingSlashMatch（Boolean  trailingSlashMatch）
     是否匹配网址，无论是否出现尾部斜杠。如果启用，映射到“/ users”的方法也匹配“/ users /”。
     默认值为true。
     * */
    @Override
    public void configurePathMatch(PathMatchConfigurer configurer) {
        configurer
//                .setUseSuffixPatternMatch(false);//不使用后缀匹配
            .setUseRegisteredSuffixPatternMatch(true);//使用后缀匹配
           //     .setUseTrailingSlashMatch(true);//是否匹配网址，无论是否出现尾部斜杠。
        // setUseRegisteredSuffixPatternMatch(Boolean registeredSuffixPatternMatch)
        //后缀模式匹配是否应该仅适用于显式注册的路径扩展
    }

    /**
     * 修改DispatcherServlet默认配置
     * PathMatchConfigurer configurer
     * .setUseRegisteredSuffixPatternMatch(true)仅适用于显式注册的路径扩展
     *  当设置为true时，下边的配置才能生效。
     */
    /**
     * @Bean
     * 主要被用在方法上，来显式声明要用生成的类;用@Configuration注解该类，等价 与XML中配置beans；
     * 用@Bean标注方法等价于XML中配置bean。
     * */
    @Bean
    public ServletRegistrationBean dispatcherRegistration(DispatcherServlet dispatcherServlet) {
        ServletRegistrationBean registration = new ServletRegistrationBean(dispatcherServlet);
        Collection<String> urlMappings = registration.getUrlMappings();

        registration.getUrlMappings().clear();
        registration.addUrlMappings("/");
        registration.getUrlMappings().remove("*.do");
        registration.getUrlMappings().remove("*.action");
        registration.getUrlMappings().remove("*.jsp");
        registration.addUrlMappings("*.json");
        registration.addUrlMappings("*.xml");


        urlMappings.forEach(a-> System.out.println("================================="+a));
        return registration;
    }

}
