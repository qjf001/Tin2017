package com.test.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017/3/8 0008.
 */
@Controller
@RequestMapping("vuejs")
public class VueJSController {

    @RequestMapping("helloVue")
    public String helloVue()
    {
        return "vue/helloVue";
    }
    @RequestMapping("table")
    public String table(Model model)
    {
        return "vue/table2";
    }

    @ResponseBody
    @RequestMapping("getTableData")
    public Map getTableData()
    {
        Map<String,Object> rdata = new HashMap<>();
        List<Map> datas = new ArrayList<>();
        Map<String,Object> map1 = new HashMap<>();
      //  map1.put("id",1);
        map1.put("nickname","张三");
        map1.put("birthday","2000-01-02");
        map1.put("sign","人生就像是一场修行人生就像是一场修行人生就像是一场修行人生就像是一场修行人生就像是一场修行人生就像是一场修行人生就像是一场修行人生就像是一场修行");

        Map<String,Object> map2 = new HashMap<>();
        map2.put("id",2);
        map2.put("nickname","李四");
        map2.put("birthday","2000-01-02");
        map2.put("sign","人生就像是一场修行");
        Map<String,Object> map3 = new HashMap<>();
        map3.put("id",3);
        map3.put("nickname","王五");
        map3.put("birthday","2000-01-02");
        map3.put("sign","人生就像是一场修行");
        Map<String,Object> map4 = new HashMap<>();
        map4.put("id",4);
        map4.put("nickname","赵六");
        map4.put("birthday","2000-01-02");
        map4.put("sign","人生就像是一场修行");
        Map<String,Object> map5 = new HashMap<>();
        map5.put("id",5);
        map5.put("nickname","周七");
        map5.put("birthday","2000-01-02");
        map5.put("sign","人生就像是一场修行");
        datas.add(map1);
        datas.add(map2);
        datas.add(map3);
        datas.add(map4);
        datas.add(map5);
        datas.add(map1);
        datas.add(map2);
        datas.add(map3);
        datas.add(map4);
        datas.add(map5);
        datas.add(map1);
        datas.add(map2);
        datas.add(map3);
        datas.add(map4);
        datas.add(map5);
        rdata.put("list",datas);
        return rdata;
    }
}
