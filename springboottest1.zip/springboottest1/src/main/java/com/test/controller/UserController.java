package com.test.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfig;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by Administrator on 2017/2/27 0027.
 */

//@RestController // 如果使用这个注解则默认返回json数据，除非方法中声明返回ModelView对象并且对应的view能够找到
@Controller
@RequestMapping("/")
public class UserController {

    @Autowired
    private FreeMarkerConfig freeMarkerConfig;//获取FreemarkerConfig的实例

    @RequestMapping("test")
    public String test(HttpServletRequest request,Model model)
    {
        model.addAttribute("user","张三");
        return "test";
    }

}
