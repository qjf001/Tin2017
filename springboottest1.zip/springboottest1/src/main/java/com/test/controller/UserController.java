package com.test.controller;

import com.alibaba.fastjson.JSON;

import com.github.pagehelper.Page;
import com.test.common.util.MyPage;
import com.test.service.impl.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfig;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2017/2/27 0027.
 */

//@RestController // 如果使用这个注解则默认返回json数据，除非方法中声明返回ModelView对象并且对应的view能够找到
@Controller
@RequestMapping("user")
public class UserController {

    @Autowired
    private FreeMarkerConfig freeMarkerConfig;//获取FreemarkerConfig的实例

    @Resource
    private UserServiceImpl userServiceImpl;

    @RequestMapping("test")
    public String test(HttpServletRequest request,Model model)
    {
        model.addAttribute("user","张三");
        return "test";
    }

    @RequestMapping("list")
    public String table(Model model)
    {
        return "user/list";
    }

    @ResponseBody
    @RequestMapping("listData")
    public Map listData(Integer pageNum, Integer pageSize,String birthday)
    {
        Map map = new HashMap<>();
        try{
            Page page = (Page)userServiceImpl.findPage(pageNum,pageSize,birthday);
            map.put("page",new MyPage<>(page));
            map.put("action",true);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            map.put("action",false);
        }
        System.out.println(JSON.toJSONString(map));
        return map;
    }

    public static void main(String[] args) throws ClassNotFoundException, SQLException {

        Class.forName("com.mysql.jdbc.Driver");
        String url = "jdbc:mysql://192.168.0.110:3306/springboot";
        String user = "root";
        String pwd = "root";
        Connection conn = DriverManager.getConnection(url,user,pwd);
        Statement s = conn.createStatement();
        ResultSet rs = s.executeQuery("select * from t_user");
        while(rs.next())
        {
            System.out.println(rs.getString("nickname"));
        }
        s.close();
        conn.close();

    }

}
