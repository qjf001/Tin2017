﻿
layui.use(['laytpl', 'element','jquery','form'], function(){
  var laytpl = layui.laytpl,element=layui.element,form=layui.form(),getTpl = tableTpl.innerHTML; var $=layui.jquery;
	try{
		if(typeof(urlStr)!='string'){alert("urlStr is not string or urlStr is not defined");return false;}
	}catch(e) {alert("urlStr is not defined");throw new Error("urlStr is not defined");return false;}
	try{
		if(!columns instanceof Array){alert("columns is not array");return false;}
	}catch(e)
	{alert("columns is not defined");throw new Error("columns is not defined");return false;}
	$.ajax({
		url:urlStr,
		async:false,
		dataType:"json",
		success:function(rdata){

			var allWidth = 0;
			$.each(columns,function(ind,valu){
				allWidth += (valu.width) ? valu.width : 0;
			});
			allWidth = (allWidth==0) ? columns.length : allWidth;
			$.each(columns,function(ind,valu){
				if(valu.width) valu.width = valu.width/allWidth*100;
			});

			rdata.columns=columns;
			rdata.noDataContent = (!window.noDataContent) ? '无数据' : noDataContent;
			rdata.title = (!window.title) ? '' : title;
			rdata.checkbox=(!window.hasCheckbox) ? true : hasCheckbox;

			laytpl(getTpl).render(rdata, function(html){
				view.innerHTML = html;
			});
		}
	});
	
  $('div.layui-form-checkbox').on('click',function(){
	if($(this).hasClass('layui-form-checked'))
	{
		$(this).removeClass('layui-form-checked');
	}
	else
	{
		$(this).addClass('layui-form-checked');
	}
  });
  $('div.layui-form-checkbox:first').on('click',function(){
  
	var child = $('table.layui-table').find('tbody div.layui-form-checkbox');
	if($(this).hasClass('layui-form-checked'))
	{
		$(this).addClass('layui-form-checked');
		child.each(function(index, item){
			$(this).addClass('layui-form-checked');
		});
	}
	else
	{
		$(this).removeClass('layui-form-checked');
		child.each(function(index, item){
			$(this).removeClass('layui-form-checked');
		});
	}
  });

	$('#moreOpenOrClose').on('click',function() {
		if ($(this).hasClass('moreClose')) {
			$(this).removeClass('moreClose');
			$(this).addClass('moreOpen');
			$(this).find('i.layui-icon').html('&#xe61a;');
			$('#moreSearchItem').addClass('layui-show');
		}
		else
		{
			$(this).removeClass('moreOpen');
			$(this).addClass('moreClose');
			$(this).find('i.layui-icon').html('&#xe619;');
			$('#moreSearchItem').removeClass('layui-show');
		}

	});

});

var getAllCheckedAttr = function()
{	
	var ids = [];
	var $ = layui.jquery;
	var child = $('table.layui-table').find('tbody div.layui-form-checked');
	child.each(function(index, item){
		var _thisId=$(this).attr('data-id');
		if(_thisId &&　_thisId!='undefined')ids.push(_thisId);
	});
	console.log(ids);
	return ids;
}
var getAllCheckedObj = function()
{	
	var objects = [];
	var $ = layui.jquery;
	var child = $('table.layui-table').find('tbody div.layui-form-checked');
	child.each(function(index, item){
		objects.push($(this).parents('tr'));
	});
	console.log(objects);
	return objects;
}