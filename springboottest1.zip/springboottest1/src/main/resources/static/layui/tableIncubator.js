﻿
layui.use(['laytpl', 'element','jquery','form'], function(){
  var laytpl = layui.laytpl,element=layui.element,form=layui.form(),getTpl = tableTpl.innerHTML; var $=layui.jquery;

	$.ajax({
		url:urlStr,
		async:false,
		dataType:"json",
		success:function(rdata){
			console.log(rdata);
			var allWidth = 0;
			$.each(columns,function(ind,valu){
				allWidth += valu.width
			});
			$.each(columns,function(ind,valu){
				valu.width = valu.width/allWidth*100;
			});

			rdata.columns=columns;
			rdata.title = title;
			rdata.checkbox=hasCheckbox;

			laytpl(getTpl).render(rdata, function(html){
				view.innerHTML = html;
			});
		}
	});


	
  $('div.layui-form-checkbox').on('click',function(){
	if($(this).hasClass('layui-form-checked'))
		$(this).removeClass('layui-form-checked');
	else
		$(this).addClass('layui-form-checked');
  });
  $('div.layui-form-checkbox:first').on('click',function(){
  
	var child = $('table.layui-table').find('tbody div.layui-form-checkbox');
	if($(this).hasClass('layui-form-checked'))
	{
	$(this).addClass('layui-form-checked');
		child.each(function(index, item){
			$(this).addClass('layui-form-checked');
		});
	}
	else
	{
		$(this).removeClass('layui-form-checked');
		child.each(function(index, item){
			$(this).removeClass('layui-form-checked');
		});
	}
  });
  
});

var getAllCheckedAttr = function()
{	
	var ids = [];
	var $ = layui.jquery;
	var child = $('table.layui-table').find('tbody div.layui-form-checked');
	child.each(function(index, item){
		ids.push($(this).attr('data-id'));
	});
	console.log(ids)
	return ids;
}
var getAllCheckedObj = function()
{	
	var objects = [];
	var $ = layui.jquery;
	var child = $('table.layui-table').find('tbody div.layui-form-checked');
	child.each(function(index, item){
		objects.push($(this).parents('tr'));
	});
	return objects;
}