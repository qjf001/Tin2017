package com.test.controller;

import com.alibaba.fastjson.JSON;
import com.github.pagehelper.Page;
import com.test.common.util.MyPage;
import com.test.common.util.ValidatorErrorMsgHelper;
import com.test.entity.User;
import com.test.service.impl.UserServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfig;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2017/2/27 0027.
 */

//@RestController // 如果使用这个注解则默认返回json数据，除非方法中声明返回ModelView对象并且对应的view能够找到
@Controller
@RequestMapping("user")
public class UserController {

    private static Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private FreeMarkerConfig freeMarkerConfig;//获取FreemarkerConfig的实例

    @Resource
    private UserServiceImpl userServiceImpl;

    @RequestMapping("test")
    public String test(HttpServletRequest request,Model model)
    {
        model.addAttribute("user","张三");
        return "test";
    }

    @RequestMapping("list")
    public String list()
    {
        // 返回页面的路径要和请求的uri一致 ，在页面可以使用${springMacroRequestContext.getRequestUri()}
        // model.addAttribute("page","user/list");
        return "layuiAdmin/commonList";
    }

    @RequestMapping("edit")
    public String edit(Model model,Integer id)
    {
        model.addAttribute("data",userServiceImpl.get(id));
        return "layuiAdmin/commonEdit";
    }

    @RequestMapping("edit2")
    public String edit2(Model model)
    {
        return "user/edit2";
    }

    /*** 返回json对象中包含date类型，会被parse成long日期，
     * 1、可以通过在实体的getter方法上添加注解 @JsonFormat(pattern="yyyy-MM-dd",timezone = "GMT+8") 解决，
     * 2、<mvc:message-converters>  进行全局配置，全局配置后，通过@JsonFormat覆盖全局配置  spirngboot中如何配置？？
     * 3、尽量避免使用Date类，可以使用Timestamp类
     * */
    @ResponseBody
    @RequestMapping("listData")
    public Map listData(@RequestParam(name="pageNum" ,defaultValue = "1",required = true)Integer pageNum, @RequestParam(name="pageSize" ,defaultValue = "10",required = true) Integer pageSize,String birthday)
    {
        Map map = new HashMap<>();
        try{
            Page page = (Page)userServiceImpl.findPage(pageNum,pageSize,birthday);
            map.put("page",new MyPage<>(page));
            map.put("action",true);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            map.put("action",false);
        }
        System.out.println(JSON.toJSONString(map));
        return map;
    }

    /** 绑定对象参数时，日期单独处理或者使用@InitBinder **/
    /** 使用hibernate的validate在服务器对请求参数进行校验 */
    /** 注意 @Validated | @Valid 于BindingResult result顺序及其他参数的顺序 **/
    @ResponseBody
    @RequestMapping("save")
    public Map saveOrUpdate(@Validated User user ,BindingResult result, Integer userId)
    {
         Map map = new HashMap<>();
        if(result.hasErrors())
           return ValidatorErrorMsgHelper.rebuildMsg(map,result);

        try{
            userServiceImpl.saveOrUpdate(user);
            map.put("action",true);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            map.put("action",false);
        }
        return map;
    }

    /**
     * 如果出现校验错误，则返回校验错误页面，如果程序运行错误则返回同一的错误页面（或者由全局异常处理）
     * **/
    @RequestMapping("save2")
    public String saveOrUpdate2(@Validated User user ,BindingResult result,Model model)
    {
        if(result.hasErrors())
            return ValidatorErrorMsgHelper.rebuildMsg( result, model);

        try{
            userServiceImpl.saveOrUpdate(user);
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
//            throw e;
        }
        return "list";
    }

    @ResponseBody
    @RequestMapping("delete")
    public Map delete(Integer id)
    {
        Map map = new HashMap<>();
        try{
          //  userServiceImpl.delete(id);
            map.put("action",true);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            map.put("action",false);
        }
        return map;
    }

    /** 用于解决springmvc controller层方法绑定date对象 */
    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.registerCustomEditor(java.util.Date.class, new CustomDateEditor(new SimpleDateFormat("yyyy-MM-dd"), true));
    }

    public static void main(String[] args) throws ClassNotFoundException, SQLException {

        Class.forName("com.mysql.jdbc.Driver");
        String url = "jdbc:mysql://127.0.0.1:3306/springboot";
        String user = "root";
        String pwd = "root";
        Connection conn = DriverManager.getConnection(url,user,pwd);
        Statement s = conn.createStatement();
        ResultSet rs = s.executeQuery("select * from t_user");
        while(rs.next())
        {
            System.out.println(rs.getString("nickname"));
        }
        s.close();
        conn.close();
    }

 }
