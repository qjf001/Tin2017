package com.test.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2017/4/4 0004.
 *
 * 系统配置
 */
@Controller
@RequestMapping("admin")
public class SystemConfigController {

    @RequestMapping("createListPage")
    public String createListPage()
    {
        return "createListPage";
    }

    @RequestMapping("saveListPage")
    @ResponseBody
    public Map saveListPage(HttpServletRequest req)
    {
        Map map = new HashMap<>();

        try{

            Map pMap = req.getParameterMap();

//            (pMap.entrySet()).stream().filter();



            map.put("action",true);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            map.put("action",false);
        }
        return map;
    }

}
