/**
 * Created by Administrator on 2017/3/27 0027.
 */
layui.use(['form', 'layedit', 'laydate','laytpl','jquery'], function(){
    var form = layui.form(),$=layui.jquery,layedit = layui.layedit;
    // 绘制表单
    layui.laytpl(formTpl.innerHTML).render(window.formRows, function(html){
        aform.innerHTML = html;
    });
    //遍历每一个表单元素，绑定富文本编辑器
    $.each(window.formRows,function(ind,valu){
        if($.isArray(valu))
        {
            $.each(valu,function(i,v){
                if(v.type==='textEdit')
                    var editIndex = layedit.build(v.formId);
            });
        }
        else {
            if(valu.type==='textEdit')
                var editIndex = layedit.build(valu.formId);
        }
    });
    form.render();

});