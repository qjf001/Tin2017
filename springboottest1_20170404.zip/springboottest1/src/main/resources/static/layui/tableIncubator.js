﻿layui.use(['layer','laytpl', 'element','jquery','form','laypage','laydate'], function(){

  var form=layui.form(),$=layui.jquery;window.tableTpl = tableTpl.innerHTML;

	// 初始化button 组(新增、批量删除等)
	if(window.bts){
		layui.laytpl(leftTopBtGroupTpl.innerHTML).render(window.bts, function(html){
			btArea.innerHTML = html;
		});
	}
	if(window.searchInputs){
		layui.laytpl(searchFormTpl.innerHTML).render(window.searchInputs, function(html){
			searchForm.innerHTML = html;
		});
	}
	form.render('radio');//searchForm以静态的方式插入到指定区域，需要动态渲染一下 form.render('select');
	try{
		if(typeof(urlStr)!='string'){alert("urlStr is not string or urlStr is not defined");return false;}
	}catch(e) {alert("urlStr is not defined");throw new Error("urlStr is not defined");return false;}
	try{
		if(!columns instanceof Array){alert("columns is not array");return false;}
	}catch(e) {alert("columns is not defined");throw new Error("columns is not defined");return false;}
	window._pageSize = (!window.pageSize) ? 10 : pageSize;//维持一个全局变量，然后将声明的全局变量的值赋给去全局变量
	window._startPageNum = 1;

	auto_initDataGrid(urlStr,_startPageNum);// 页面打开，初始化数据表格第一页

	$('#searchForm .layui-inline .layui-btn-group .searchItemMore').on('click',function() {
		if ($(this).hasClass('moreClose')) {
			$(this).removeClass('moreClose');
			$(this).addClass('moreOpen');
			$(this).find('i.layui-icon').html('&#xe61a;');
			$('#moreSearchItem').addClass('layui-show');
			if($(this).parent().parent().hasClass('searchBtGroupPC'))
			{
				var bt = $(this).parent().parent().next().find('.searchItemMore');
				bt.removeClass('moreClose');
				bt.addClass('moreOpen');
				bt.find('i.layui-icon').html('&#xe61a;');
			}
			if($(this).parent().parent().hasClass('searchBtGroupMobile'))
			{
				var bt = $(this).parent().parent().prev().find('.searchItemMore');
				bt.removeClass('moreClose');
				bt.addClass('moreOpen');
				bt.find('i.layui-icon').html('&#xe61a;');
			}
		}
		else
		{
			$(this).removeClass('moreOpen');
			$(this).addClass('moreClose');
			$(this).find('i.layui-icon').html('&#xe619;');
			$('#moreSearchItem').removeClass('layui-show');
			if($(this).parent().parent().hasClass('searchBtGroupPC'))
			{
				var bt = $(this).parent().parent().next().find('.searchItemMore');
				bt.removeClass('moreOpen');
				bt.addClass('moreClose');
				bt.find('i.layui-icon').html('&#xe619;');
			}
			if($(this).parent().parent().hasClass('searchBtGroupMobile'))
			{
				var bt = $(this).parent().parent().prev().find('.searchItemMore');
				bt.removeClass('moreOpen');
				bt.addClass('moreClose');
				bt.find('i.layui-icon').html('&#xe619;');
			}
		}
	});

});

var auto_initDataGrid = function(urlStr,currentPage){
	var laytpl = layui.laytpl; var $=layui.jquery;
	// 获取请求参数：1、翻页参数pageNum和pageSize，2、查询条件
	var searchItem = $("#searchForm").serialize();

	$.ajax({
		url:urlStr+"?pageNum="+currentPage+"&pageSize="+_pageSize+"&"+searchItem,
		async:false,
		dataType:"json",
		success:function(data){
			var page = data.page;
			var allWidth = 0;
			$.each(columns,function(ind,valu){allWidth += (valu.width) ? valu.width : 0;});
			allWidth = (allWidth==0) ? columns.length : allWidth;
			$.each(columns,function(ind,valu){if(valu.width) valu.width = valu.width/allWidth*100;});
			page.columns=window.columns;
			page.noDataContent = (!window.noDataContent) ? '无数据' : noDataContent;
			page.title = (!window.title) ? '' : title;
			page.checkbox=(window.hasCheckbox===undefined) ? true : window.hasCheckbox;
			laytpl(tableTpl).render(page, function(html){
				tableGrid.innerHTML = html;
			});
			layui.form().render();
			window._pageSize=page.pageSize;
			auto_initPager(page);
		}
	});
}
var auto_initPager = function(page)
{
	var $=layui.jquery;
	window._pageNum = page.pageNum;
	try{
		layui.laypage({// 实例化分页,偶尔会出现layui.laypage没有加载上的情况
			cont: 'pager'
			,curr:page.pageNum
			,pages: page.pages //得到总页数
			,skip: true
		});
	}
	catch(e)
	{
		layui.layer.msg(' server is not ready yet ! And the page will be reload after 2 second ',{icon:5,time:2000},function(){
			window.location.reload();
		});
	}

	// 翻页事件手动绑定
	$('#pager .layui-laypage a').on('click',function(){
	 	auto_initDataGrid(urlStr,$(this).attr("data-page"),_pageSize);
	 });
	$('#pager button.layui-laypage-btn').on('click',function(){
		var skipNum = $('#pager input.layui-laypage-skip').val();
		auto_initDataGrid(urlStr,skipNum,_pageSize);
	});
	$('#pager input.layui-laypage-skip').on('keydown',function(e){
		if(e.keyCode===13)
			auto_initDataGrid(urlStr,$(this).val(),_pageSize);
	});
}
var childClick = function(obj){
	var $=layui.jquery;
	if($(obj).hasClass('layui-form-checked'))
		$(obj).removeClass('layui-form-checked');
	else
		$(obj).addClass('layui-form-checked');
}
var parentClick = function(obj)
{
	var $=layui.jquery;
	var child = $('table.layui-table').find('tbody div.layui-form-checkbox');
	if(!$(obj).hasClass('layui-form-checked'))
	{
		$(obj).addClass('layui-form-checked');
		child.each(function(index, item){$(this).addClass('layui-form-checked');});
	}
	else
	{
		$(obj).removeClass('layui-form-checked');
		child.each(function(index, item){$(this).removeClass('layui-form-checked');});
	}
}

var getAllCheckedAttr = function()
{
	var ids = [];
	var $ = layui.jquery;
	var child = $('table.layui-table').find('tbody div.layui-form-checked');
	child.each(function(index, item){
		var _thisId=$(this).attr('data-id');
		if(_thisId &&　_thisId!='undefined')ids.push(_thisId);
	});
	console.log(ids);
	return ids;
}
var getAllCheckedObj = function()
{
	var objects = [];
	var $ = layui.jquery;
	var child = $('table.layui-table').find('tbody div.layui-form-checked');
	child.each(function(index, item){
		objects.push($(this).parents('tr'));
	});
	console.log(objects);
	return objects;
}
String.prototype.endWith=function(s){
	if(s==null||s==""||this.length==0||s.length>this.length)
		return false;
	if(this.substring(this.length-s.length)==s)
		return true;
	else
		return false;
	return true;
}
String.prototype.startWith=function(s){
	if(s==null||s==""||this.length==0||s.length>this.length)
		return false;
	if(this.substr(0,s.length)==s)
		return true;
	else
		return false;
	return true;
}
var openPage = function(urlStr,title,width,height,anim,fullScreen)
{
	if(width===undefined)width=window.screen.width*0.8;
	if(height===undefined)height=window.screen.height*0.8;
	if(isNaN(width))throw new Error(" width is not a number ");
	if(isNaN(height))throw new Error(" height is not a number ");
	if(width > window.screen.width)throw new Error(" width is too large ");
	if(height > window.screen.height)throw new Error(" height is too large ");
	if(isNaN(anim))anim = 3;
	var index = layui.layer.open({
		type: 2,// type=1 弹层为普通，不会请求链接
		title: title===undefined ? "  " : title,// 没有title也要站个位
		skin: 'layui-layer-molv',// title皮肤
		shadeClose: false,// 点击遮罩不关闭
		shade: true,// 遮罩父窗口
		maxmin: true, //开启最大化最小化按钮
		fixed:true,
		anim: anim,// 来点动画 1-从上中弹出，2-从下方弹出，3-从中间来，4-左下方旋出来，5-从中间来，6-抖出来，
		area: [width+'px',height+'px'],
		content: urlStr
	});
	if(fullScreen)layui.layer.full(index);// 弹出即全屏
}
var closeOpenPage=function(){
	layer.closeAll('iframe');
}
var del = function(id)
{
	console.log(id);
	layui.layer.confirm("您确定删除该记录？",{icon: 3, title:'提示'},function(){
		layui.jquery.ajax({
			url:"delete",
			data:{"id":id},
			type:"post",
			dataType:"json",
			success:function(data)
			{
				if(data.action)
					layui.layer.alert("操作成功",{icon: 1, title:'提示'},function(index){
						window.parent.auto_initDataGrid(window.urlStr,window._pageNum);
						layer.close(index);
					});
				else
					layui.layer.alert("操作失败");
			}
		});
	},function(){});
}
