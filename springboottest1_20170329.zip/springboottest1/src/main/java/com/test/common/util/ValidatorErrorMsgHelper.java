package com.test.common.util;

import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;

import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017/3/29.
 */
public class ValidatorErrorMsgHelper {

    /*** 客户端接收json格式的数据，然后将msg的内容以html的格式输出，输出采用的是layer的alert */
    public static Map rebuildMsg(Map map,BindingResult result){
        List<FieldError> errors = result.getFieldErrors();
        String msg = new String();
        for(FieldError error : errors)
        {
            System.out.println(error.getField()+"   "+error.getDefaultMessage());
            msg += " <p>["+error.getField()+"]"+error.getDefaultMessage()+";</p> ";
        }
        map.put("action",false);
        map.put("msg",msg);
        return map;
    }

    public static String rebuildMsg(BindingResult result,Model model){
        List<FieldError> errors = result.getFieldErrors();
        String msg = new String();
        for(FieldError error : errors)
        {
            System.out.println(error.getField()+"   "+error.getDefaultMessage());
            msg += " <p>["+error.getField()+"]"+error.getDefaultMessage()+";</p> ";
        }
        model.addAttribute("msg",msg);
        return "/error/validatorErrorPage";
    }

}
